import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'NIX SALES CRM', description: 'NIX Sales Management Platform' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
 return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
