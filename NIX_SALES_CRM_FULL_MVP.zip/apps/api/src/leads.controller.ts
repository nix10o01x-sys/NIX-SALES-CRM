import { Body, Controller, Get, Post } from '@nestjs/common';
import { IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { PrismaService } from './prisma.service';

class CreateLeadDto {
 @IsString() @IsNotEmpty() companyId!: string;
 @IsString() @IsNotEmpty() name!: string;
 @IsString() @IsNotEmpty() phone!: string;
 @IsOptional() @IsString() source?: string;
 @IsOptional() @IsString() notes?: string;
}
@Controller('leads')
export class LeadsController {
 constructor(private readonly prisma: PrismaService) {}
 // MVP scaffold only: companyId must come from authenticated server-side identity before production.
 @Get() async list(){ return this.prisma.lead.findMany({ take:100, orderBy:{createdAt:'desc'}, include:{owner:{select:{id:true,name:true}}} }); }
 @Post() async create(@Body() dto: CreateLeadDto) {
  return this.prisma.lead.create({data:{companyId:dto.companyId,name:dto.name,phone:dto.phone,source:dto.source,notes:dto.notes?{create:{body:dto.notes}}:undefined}});
 }
}
