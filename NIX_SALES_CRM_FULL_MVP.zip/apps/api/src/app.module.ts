import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { PrismaService } from './prisma.service';
import { LeadsController } from './leads.controller';
@Module({ controllers: [AppController, LeadsController], providers: [PrismaService] })
export class AppModule {}
