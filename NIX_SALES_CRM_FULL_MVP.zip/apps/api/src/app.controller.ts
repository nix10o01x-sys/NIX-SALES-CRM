import { Controller, Get } from '@nestjs/common';
@Controller()
export class AppController {
 @Get('health') health(){ return { service:'NIX SALES CRM API', status:'ok', version:'1.0.0' }; }
}
