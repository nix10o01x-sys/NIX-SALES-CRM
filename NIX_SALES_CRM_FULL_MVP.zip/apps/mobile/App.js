import React,{useState} from 'react';
import {SafeAreaView,ScrollView,Text,View,StyleSheet,TextInput,Pressable,Alert} from 'react-native';
const seed=[{id:'1',name:'أحمد محمد',phone:'01000000421',status:'مهتم',note:'طلب تفاصيل الأسعار'},{id:'2',name:'مريم علي',phone:'01100000830',status:'متابعة',note:'إعادة الاتصال غدًا'},{id:'3',name:'يوسف خالد',phone:'01200000195',status:'لم يرد',note:''}];
export default function App(){
 const [leads,setLeads]=useState(seed),[name,setName]=useState(''),[phone,setPhone]=useState('');
 const add=()=>{if(!name.trim()||!phone.trim()){Alert.alert('بيانات ناقصة','اكتب اسم العميل ورقم الهاتف');return}setLeads([{id:Date.now().toString(),name,phone,status:'جديد',note:''},...leads]);setName('');setPhone('')};
 return <SafeAreaView style={s.page}><ScrollView contentContainerStyle={s.content}>
 <Text style={s.brand}>NIX SALES</Text><Text style={s.sub}>مساحة عمل فريق المبيعات</Text><Text style={s.title}>عملائي</Text>
 <View style={s.stats}><View style={s.box}><Text style={s.sub}>إجمالي العملاء</Text><Text style={s.num}>{leads.length}</Text></View><View style={s.box}><Text style={s.sub}>مهتمون</Text><Text style={s.num}>{leads.filter(x=>x.status==='مهتم').length}</Text></View></View>
 <Text style={s.heading}>إضافة عميل سريع</Text><TextInput style={s.input} placeholder="اسم العميل" value={name} onChangeText={setName}/><TextInput style={s.input} placeholder="رقم الهاتف" keyboardType="phone-pad" value={phone} onChangeText={setPhone}/><Pressable style={s.btn} onPress={add}><Text style={s.btnText}>إضافة العميل</Text></Pressable>
 <Text style={s.heading}>قائمة العملاء</Text>{leads.map(x=><View style={s.lead} key={x.id}><Text style={s.name}>{x.name}</Text><Text style={s.status}>{x.phone} · {x.status}</Text>{x.note?<Text style={s.note}>{x.note}</Text>:null}</View>)}
 <Text style={s.footer}>نسخة MVP تجريبية — ستتم مزامنة البيانات مع API بعد استكمال المصادقة والربط.</Text>
 </ScrollView></SafeAreaView>
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:'#f5f7fb'},content:{padding:20,paddingTop:30},brand:{fontSize:24,fontWeight:'900',color:'#1769e0'},sub:{color:'#78849a',marginTop:5},title:{fontSize:25,fontWeight:'800',color:'#172033',marginTop:27,marginBottom:16},stats:{flexDirection:'row',gap:12},box:{flex:1,backgroundColor:'#fff',padding:17,borderRadius:15},num:{fontSize:27,fontWeight:'800',color:'#172033',marginTop:7},heading:{fontSize:18,fontWeight:'700',marginTop:25,marginBottom:12,color:'#172033'},input:{backgroundColor:'#fff',borderWidth:1,borderColor:'#e1e7f0',borderRadius:11,padding:13,marginBottom:10,textAlign:'right'},btn:{backgroundColor:'#1769e0',padding:14,borderRadius:11,alignItems:'center'},btnText:{color:'#fff',fontWeight:'800'},lead:{backgroundColor:'#fff',padding:16,borderRadius:14,marginBottom:10},name:{fontWeight:'800',fontSize:16,color:'#172033'},status:{color:'#1769e0',marginTop:7},note:{color:'#78849a',marginTop:5},footer:{color:'#8993a4',fontSize:12,marginTop:18}});
