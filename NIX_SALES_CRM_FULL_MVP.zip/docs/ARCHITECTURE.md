# Architecture

## Stack
- Web: Next.js App Router + React + TypeScript.
- Mobile: Expo + React Native.
- API: NestJS + Prisma.
- Database: PostgreSQL.
- UI: NIX LIGHT, Arabic RTL, responsive layout.

## Roles
- `SUPER_ADMIN`: platform-level company and subscription administration.
- `COMPANY_MANAGER`: manages one tenant, agents, leads, reports and settings.
- `SALES_AGENT`: sees assigned leads and records call outcomes.

## Lead lifecycle
`NEW` → `CONTACTED` → `INTERESTED` / `CALLBACK` / `NO_ANSWER` / `NOT_INTERESTED` / `WRONG_NUMBER` → `WON` / `LOST`.

## Tenant security requirements
Every tenant-owned row must carry `companyId`. Derive the company from the authenticated session/JWT on the server, never from a client-supplied company ID alone. Enforce tenant scope in every query and mutation. Add audit events for sensitive changes.

## Before production
1. Implement authentication and password hashing (Argon2id/bcrypt) and refresh-token rotation.
2. Add role guards and tenant-scoped authorization to every route.
3. Add DTO validation, rate limiting, CSRF strategy for cookie sessions, secure headers and TLS.
4. Add integration tests, migrations, backups, monitoring and error reporting.
5. Review local privacy/telemarketing requirements and record lawful consent/preferences.
