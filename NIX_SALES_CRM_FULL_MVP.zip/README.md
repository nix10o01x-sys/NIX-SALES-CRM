# NIX SALES CRM — Full MVP Monorepo

واجهة عربية RTL بهوية NIX LIGHT، مع تطبيق ويب وتطبيق Expo للموبايل وAPI وقاعدة بيانات PostgreSQL.

## المكونات
- `apps/web`: Next.js dashboard مع إدارة عملاء تجريبية محلية.
- `apps/mobile`: Expo / React Native واجهة متابعة الموظف.
- `apps/api`: NestJS API مع Prisma schema وواجهات صحة الخدمة والعملاء (هيكل ربط أولي).
- `infra/docker-compose.yml`: PostgreSQL محلي.
- `docs`: خطوات التشغيل والمعمارية وقائمة ما يلزم قبل الإنتاج.

## المتطلبات
Node.js 20+، npm، Docker (لقاعدة البيانات)، وExpo Go للموبايل.

## التشغيل
### 1) قاعدة البيانات
```bash
cd infra
docker compose up -d
```

### 2) API
```bash
cd apps/api
cp .env.example .env
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run start:dev
```
API على `http://localhost:4000`، وفحص الحالة على `/health`.

### 3) الويب
```bash
cd apps/web
npm install
npm run dev
```
افتح `http://localhost:3000`.

### 4) تطبيق الموبايل
```bash
cd apps/mobile
npm install
npx expo start
```
امسح QR باستخدام Expo Go. لتوصيل الهاتف بالـ API، ضع عنوان IP المحلي لجهاز التطوير في `EXPO_PUBLIC_API_URL` داخل `apps/mobile/.env`.

## ملاحظات مهمة
هذه نسخة MVP تأسيسية قابلة للتشغيل والتطوير وليست جاهزة للبيع أو الإنتاج كما هي. لوحة الويب الحالية تستخدم بيانات محلية في المتصفح للتجربة، بينما API وPrisma يقدمان أساس الربط الخلفي. يجب إكمال المصادقة، عزل الشركات، الصلاحيات، التحقق من المدخلات، الاختبارات، النسخ الاحتياطية، وسياسة الخصوصية قبل إدخال بيانات عملاء حقيقية.
